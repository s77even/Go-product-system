package controllers

import (
	"github.com/kataras/iris"
	"github.com/kataras/iris/mvc"
	"github.com/kataras/iris/sessions"
	"imooc-product/services"
)

type UserController struct {
	ctx iris.Context
	Service services.IUserService
	Session *sessions.Session
}
func(c *UserController)GetRegister()mvc.View{
	return mvc.View{
		Name: "user/register.html",
	}
}